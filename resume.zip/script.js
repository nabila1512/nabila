function toggleMenu() {
    const menuLinks = document.querySelector('.menu-links');
    menuLinks.classList.toggle('show-menu');
}

document.addEventListener('DOMContentLoaded', function () {
    function addFadeInAnimation() {
      const elementsToAnimate = document.querySelectorAll('.fade-in');
      
      elementsToAnimate.forEach(function (element) {
        element.classList.add('fade-in');
      });
    }
      addFadeInAnimation();
  });
  


